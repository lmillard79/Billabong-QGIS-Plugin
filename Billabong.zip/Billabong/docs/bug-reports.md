---
title: Bug Reports and Feature Requests
layout: page
nav_order: 5
permalink: /issues/
---

# Bug Reports and Feature Requests

If you encounter any bugs or have feature requests, please feel free to create an issue in our [GitHub repository](https://github.com/lmillard79/Billabong/issues). We appreciate your feedback!
