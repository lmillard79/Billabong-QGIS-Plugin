PLUGIN_NAME = "Billabong"

QLR_URL = (
    "https://raw.githubusercontent.com/lmillard79/Billabong-QGIS-Plugin/main/data/billabong.qlr"
)

ABOUT_FILE_URL = "https://lmillard79.github.io/Billabong/"
